
export interface PlantAnalysis {
  id: string;
  timestamp: number;
  image: string;
  diseaseName: string;
  confidence: number;
  symptoms: string[];
  severity: 'Low' | 'Moderate' | 'High' | 'Critical';
  treatment: string;
  irrigationAdvice: string;
  nutrientAdvice: string;
  pestPrevention: string;
  isHealthy: boolean;
  earlyRiskFactors?: string[];
}

export type AppView = 'dashboard' | 'scan' | 'history' | 'education' | 'guide' | 'voice';

export interface DiseaseInfo {
  name: string;
  category: string;
  description: string;
  symptoms: string[];
  prevention: string;
}

export interface CropDetail {
  name: string;
  scientificName: string;
  sunlight: string;
  watering: string;
  soil: string;
  fertilizer: string;
  pruning: string;
  commonPests: string[];
  difficulty: 'Easy' | 'Moderate' | 'Challenging';
  imagePlaceholder?: string;
}

export interface AIAdvice {
  query: string;
  response: string;
  tips: string[];
}

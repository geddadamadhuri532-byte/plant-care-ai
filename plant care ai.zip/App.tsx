
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AppView, PlantAnalysis, DiseaseInfo, CropDetail, AIAdvice } from './types';
import { analyzePlantImage, getDiseaseKnowledgeBase, getAIPlantAdvice, getPlantEncyclopedia } from './services/gemini';
import { PLANT_GUIDE_STEPS } from './constants';
import CameraCapture from './components/CameraCapture';
import AnalysisResult from './components/AnalysisResult';
import MonitoringHistory from './components/MonitoringHistory';
import VoiceAssistant from './components/VoiceAssistant';
import JSZip from 'jszip';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('dashboard');
  const [learnTab, setLearnTab] = useState<'knowledge' | 'encyclopedia'>('knowledge');
  const [history, setHistory] = useState<PlantAnalysis[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedAnalysis, setSelectedAnalysis] = useState<PlantAnalysis | null>(null);
  const [knowledgeBase, setKnowledgeBase] = useState<DiseaseInfo[]>([]);
  const [encyclopedia, setEncyclopedia] = useState<CropDetail[]>([]);
  const [selectedCrop, setSelectedCrop] = useState<CropDetail | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [aiAdvice, setAiAdvice] = useState<AIAdvice | null>(null);
  const [isSearchingAI, setIsSearchingAI] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('flora_health_history');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse history", e);
        localStorage.removeItem('flora_health_history');
      }
    }

    const loadData = async () => {
      try {
        const [kb, ep] = await Promise.all([
          getDiseaseKnowledgeBase(),
          getPlantEncyclopedia()
        ]);
        setKnowledgeBase(kb);
        setEncyclopedia(ep);
      } catch (e) {
        console.error("Data failed to load", e);
      }
    };
    loadData();
  }, []);

  const downloadFullProject = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();
      
      // We fetch current page sources as strings. 
      // In this environment, we represent the virtual file system.
      const files = {
        'index.html': document.documentElement.outerHTML,
        'manifest.json': await fetch('manifest.json').then(r => r.text()).catch(() => '{}'),
        'metadata.json': await fetch('metadata.json').then(r => r.text()).catch(() => '{}'),
        'App.tsx': await fetch('App.tsx').then(r => r.text()).catch(() => ''),
        'index.tsx': await fetch('index.tsx').then(r => r.text()).catch(() => ''),
        'types.ts': await fetch('types.ts').then(r => r.text()).catch(() => ''),
        'constants.tsx': await fetch('constants.tsx').then(r => r.text()).catch(() => ''),
        'services/gemini.ts': await fetch('services/gemini.ts').then(r => r.text()).catch(() => ''),
        'services/audio.ts': await fetch('services/audio.ts').then(r => r.text()).catch(() => ''),
        'components/CameraCapture.tsx': await fetch('components/CameraCapture.tsx').then(r => r.text()).catch(() => ''),
        'components/AnalysisResult.tsx': await fetch('components/AnalysisResult.tsx').then(r => r.text()).catch(() => ''),
        'components/MonitoringHistory.tsx': await fetch('components/MonitoringHistory.tsx').then(r => r.text()).catch(() => ''),
        'components/VoiceAssistant.tsx': await fetch('components/VoiceAssistant.tsx').then(r => r.text()).catch(() => ''),
      };

      Object.entries(files).forEach(([path, content]) => {
        zip.file(path, content);
      });

      const content = await zip.generateAsync({ type: "blob" });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(content);
      link.download = "plant-care-ai-project.zip";
      link.click();
    } catch (err) {
      console.error("Export failed:", err);
      alert("Could not generate ZIP. Please check your browser permissions.");
    } finally {
      setIsExporting(false);
    }
  };

  const saveHistoryToStorage = useCallback((newHistory: PlantAnalysis[]) => {
    try {
      const prunedHistory = newHistory.slice(0, 20);
      localStorage.setItem('flora_health_history', JSON.stringify(prunedHistory));
      setHistory(prunedHistory);
    } catch (e) {
      console.warn("Storage full, cleaning up older records...");
      try {
        const minimalHistory = newHistory.slice(0, 5);
        localStorage.setItem('flora_health_history', JSON.stringify(minimalHistory));
        setHistory(minimalHistory);
      } catch (err) {
        alert("Storage is completely full. Please clear history in Monitor tab.");
      }
    }
  }, []);

  const clearHistory = () => {
    if (window.confirm("Are you sure you want to delete all plant scan history?")) {
      localStorage.removeItem('flora_health_history');
      setHistory([]);
    }
  };

  const exportHistoryJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(history, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "plant_health_history.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleVoiceSearch = useCallback(async (query: string) => {
    setView('education');
    setSearchQuery(query);
    setIsSearchingAI(true);
    setAiAdvice(null);
    try {
      const advice = await getAIPlantAdvice(query);
      setAiAdvice(advice);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearchingAI(false);
    }
  }, []);

  const handleAISearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearchingAI(true);
    setAiAdvice(null);
    try {
      const advice = await getAIPlantAdvice(searchQuery);
      setAiAdvice(advice);
    } catch (err) {
      alert("Failed to get AI advice. Please try again.");
    } finally {
      setIsSearchingAI(false);
    }
  };

  const handleCapture = async (image: string) => {
    setIsAnalyzing(true);
    try {
      const result = await analyzePlantImage(image);
      const newHistory = [result, ...history];
      saveHistoryToStorage(newHistory);
      setSelectedAnalysis(result);
    } catch (err) {
      alert("Analysis failed. Please try again with a clearer image.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const filteredKnowledgeBase = useMemo(() => {
    if (!searchQuery.trim()) return knowledgeBase;
    const lowerQuery = searchQuery.toLowerCase();
    return knowledgeBase.filter(item => 
      item.name.toLowerCase().includes(lowerQuery) || 
      item.category.toLowerCase().includes(lowerQuery) ||
      item.description.toLowerCase().includes(lowerQuery)
    );
  }, [knowledgeBase, searchQuery]);

  const filteredEncyclopedia = useMemo(() => {
    if (!searchQuery.trim()) return encyclopedia;
    const lowerQuery = searchQuery.toLowerCase();
    return encyclopedia.filter(item => 
      item.name.toLowerCase().includes(lowerQuery) || 
      item.scientificName.toLowerCase().includes(lowerQuery)
    );
  }, [encyclopedia, searchQuery]);

  const NavItem = ({ icon, label, id }: { icon: React.ReactNode, label: string, id: AppView }) => (
    <button 
      onClick={() => setView(id)}
      className={`flex flex-col items-center gap-1 p-2 transition-all ${view === id ? 'text-green-700 font-bold' : 'text-stone-400 hover:text-stone-600'}`}
    >
      <div className={`${view === id ? 'bg-green-100 p-2 rounded-xl' : ''}`}>
        {icon}
      </div>
      <span className="text-[10px] uppercase tracking-widest">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <header className="sticky top-0 bg-stone-50/80 backdrop-blur-md z-40 p-4 border-b">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-green-700 rounded-xl flex items-center justify-center text-white shadow-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            </div>
            <h1 className="text-xl font-serif font-bold text-stone-900">Plant Care <span className="text-green-700">AI</span></h1>
          </div>
          <button 
            onClick={() => setView('guide')}
            className={`p-2 rounded-full transition-colors ${view === 'guide' ? 'bg-green-100 text-green-700' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto mt-6">
        {view === 'dashboard' && (
          <div className="px-4 space-y-8">
            <div className="bg-gradient-to-br from-green-700 to-green-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
              <div className="relative z-10">
                <h2 className="text-4xl font-serif font-bold mb-2">Grow with confidence.</h2>
                <p className="text-green-100 mb-8 max-w-md">Our AI analysis identifies diseases, nutrient deficiencies, and provides early screening alerts for your crops.</p>
                <button 
                  onClick={() => setView('scan')}
                  className="bg-white text-green-900 px-8 py-4 rounded-2xl font-bold shadow-lg hover:scale-105 active:scale-95 transition-all"
                >
                  Scan New Plant
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Total Scans', value: history.length, icon: '📊', color: 'bg-stone-100' },
                { label: 'Healthy Plants', value: history.filter(h => h.isHealthy).length, icon: '🌿', color: 'bg-green-100' },
                { label: 'Critical Alerts', value: history.filter(h => h.severity === 'Critical').length, icon: '⚠️', color: 'bg-red-100' },
                { label: 'Encyclopedia', value: encyclopedia.length, icon: '📖', color: 'bg-blue-100' },
              ].map((stat, i) => (
                <div key={i} className={`p-6 rounded-3xl ${stat.color} shadow-sm border border-transparent hover:border-stone-200 transition-all`}>
                  <div className="text-3xl mb-2">{stat.icon}</div>
                  <div className="text-stone-500 text-xs font-bold uppercase tracking-widest">{stat.label}</div>
                  <div className="text-3xl font-bold text-stone-900">{stat.value}</div>
                </div>
              ))}
            </div>

            <MonitoringHistory history={history.slice(0, 3)} onViewDetails={setSelectedAnalysis} />
          </div>
        )}

        {view === 'scan' && (
          <div className="px-4 animate-in slide-in-from-bottom-4 duration-500">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-serif font-bold text-stone-900">Plant Diagnosis</h2>
              <p className="text-stone-500 mt-2">Position the leaf in the frame for real-time analysis.</p>
            </div>
            <CameraCapture onCapture={handleCapture} isAnalyzing={isAnalyzing} />
            {isAnalyzing && (
              <div className="mt-8 text-center space-y-4">
                <div className="flex justify-center">
                  <div className="w-12 h-12 border-4 border-green-600 border-t-transparent rounded-full animate-spin"></div>
                </div>
                <p className="text-stone-600 font-medium animate-pulse">Consulting the digital botanist...</p>
              </div>
            )}
          </div>
        )}

        {view === 'history' && (
          <div className="px-4 animate-in fade-in duration-500">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-stone-800">Scan History</h2>
              <div className="flex gap-2">
                {history.length > 0 && (
                  <>
                    <button 
                      onClick={exportHistoryJSON}
                      className="text-xs font-bold text-green-700 hover:text-green-800 uppercase tracking-widest flex items-center gap-2 px-4 py-2 bg-green-50 rounded-xl transition-all shadow-sm"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0L8 8m4-4v12" />
                      </svg>
                      JSON Export
                    </button>
                    <button 
                      onClick={clearHistory}
                      className="text-xs font-bold text-red-600 hover:text-red-800 uppercase tracking-widest flex items-center gap-2 px-4 py-2 bg-red-50 rounded-xl transition-all"
                    >
                      Clear All
                    </button>
                  </>
                )}
              </div>
            </div>
            <MonitoringHistory history={history} onViewDetails={setSelectedAnalysis} />
          </div>
        )}

        {view === 'education' && (
          <div className="px-4 space-y-8 animate-in fade-in duration-500">
            {/* Search and Tabs */}
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <h2 className="text-3xl font-serif font-bold text-stone-900">Learning Center</h2>
                <div className="flex gap-2">
                  <div className="relative w-full md:w-80">
                    <input
                      type="text"
                      className="block w-full pl-10 pr-3 py-3 border border-stone-200 rounded-2xl bg-white focus:outline-none focus:ring-2 focus:ring-green-500 transition-all text-sm"
                      placeholder="Ask AI or search database..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg className="h-5 w-5 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    </div>
                  </div>
                  <button 
                    onClick={handleAISearch}
                    disabled={isSearchingAI || !searchQuery.trim()}
                    

import React, { useRef, useState, useCallback } from 'react';

interface CameraCaptureProps {
  onCapture: (image: string) => void;
  isAnalyzing: boolean;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, isAnalyzing }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [showCamera, setShowCamera] = useState(false);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setShowCamera(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
      alert("Could not access camera. Please check permissions.");
    }
  };

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setShowCamera(false);
    }
  }, [stream]);

  const processAndCapture = (source: HTMLVideoElement | HTMLImageElement) => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // High-quality resizing to save storage space
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = source instanceof HTMLVideoElement ? source.videoWidth : source.width;
        let height = source instanceof HTMLVideoElement ? source.videoHeight : source.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(source, 0, 0, width, height);
        
        // Lower quality to 0.7 to significantly reduce string size
        const imageData = canvas.toDataURL('image/jpeg', 0.7);
        onCapture(imageData);
        stopCamera();
      }
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      processAndCapture(videoRef.current);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => processAndCapture(img);
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full max-w-lg mx-auto p-4">
      {!showCamera ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
          <button
            onClick={startCamera}
            disabled={isAnalyzing}
            className="flex flex-col items-center justify-center p-8 bg-green-600 hover:bg-green-700 text-white rounded-2xl transition-all shadow-lg hover:shadow-xl disabled:opacity-50"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span className="font-semibold text-lg">Use Camera</span>
          </button>

          <label className={`flex flex-col items-center justify-center p-8 bg-white border-2 border-dashed border-green-300 hover:border-green-500 text-green-700 rounded-2xl cursor-pointer transition-all shadow-sm hover:shadow-md ${isAnalyzing ? 'opacity-50 pointer-events-none' : ''}`}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            <span className="font-semibold text-lg">Upload Photo</span>
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      ) : (
        <div className="relative w-full rounded-3xl overflow-hidden bg-black shadow-2xl">
          <video ref={videoRef} autoPlay playsInline className="w-full h-auto aspect-square object-cover" />
          <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4 px-4">
            <button
              onClick={stopCamera}
              className="p-4 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/30 transition-all"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <button
              onClick={capturePhoto}
              className="p-6 bg-green-500 rounded-full text-white shadow-xl hover:scale-110 active:scale-95 transition-all border-4 border-white"
            >
              <div className="w-8 h-8 rounded-full border-2 border-white"></div>
            </button>
          </div>
          <canvas ref={canvasRef} className="hidden" />
        </div>
      )}
    </div>
  );
};

export default CameraCapture;


import React from 'react';
import { PlantAnalysis } from '../types';

interface AnalysisResultProps {
  analysis: PlantAnalysis;
  onClose: () => void;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ analysis, onClose }) => {
  const severityColors = {
    Low: 'bg-green-100 text-green-800',
    Moderate: 'bg-yellow-100 text-yellow-800',
    High: 'bg-orange-100 text-orange-800',
    Critical: 'bg-red-100 text-red-800'
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl animate-in fade-in zoom-in duration-300">
        <div className="sticky top-0 bg-white/80 backdrop-blur-md z-10 flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-stone-800">Diagnostic Report</h2>
          <button onClick={onClose} className="p-2 hover:bg-stone-100 rounded-full transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <img src={analysis.image} alt="Analyzed Leaf" className="w-full rounded-2xl shadow-inner aspect-square object-cover bg-stone-100" />
              
              <div className="mt-6 space-y-4">
                <div className="flex items-center justify-between p-4 bg-stone-50 rounded-xl">
                  <span className="text-stone-500 font-medium">Confidence</span>
                  <span className="text-lg font-bold text-green-700">{(analysis.confidence * 100).toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-stone-50 rounded-xl">
                  <span className="text-stone-500 font-medium">Severity</span>
                  <span className={`px-4 py-1 rounded-full text-sm font-bold ${severityColors[analysis.severity]}`}>
                    {analysis.severity}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-3xl font-serif text-stone-900 mb-2">{analysis.diseaseName}</h3>
                <div className="flex flex-wrap gap-2">
                  {analysis.isHealthy ? (
                    <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Healthy Flora</span>
                  ) : (
                    <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Ailment Detected</span>
                  )}
                </div>
              </div>

              <section>
                <h4 className="font-bold text-stone-800 mb-2 flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                  </svg>
                  Visible Symptoms
                </h4>
                <ul className="list-disc list-inside space-y-1 text-stone-600">
                  {analysis.symptoms.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
              </section>

              <section>
                <h4 className="font-bold text-stone-800 mb-2 flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                  Treatment Plan
                </h4>
                <p className="text-stone-600 leading-relaxed">{analysis.treatment}</p>
              </section>

              {analysis.earlyRiskFactors && analysis.earlyRiskFactors.length > 0 && (
                <section className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                  <h4 className="font-bold text-amber-800 mb-2 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    Early Screening Alerts
                  </h4>
                  <ul className="list-disc list-inside text-amber-700 text-sm">
                    {analysis.earlyRiskFactors.map((f, i) => <li key={i}>{f}</li>)}
                  </ul>
                </section>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12 border-t pt-8">
            <div className="p-4 bg-blue-50 rounded-2xl">
              <h5 className="font-bold text-blue-800 mb-2 uppercase text-xs tracking-widest">Irrigation</h5>
              <p className="text-sm text-blue-700">{analysis.irrigationAdvice}</p>
            </div>
            <div className="p-4 bg-emerald-50 rounded-2xl">
              <h5 className="font-bold text-emerald-800 mb-2 uppercase text-xs tracking-widest">Nutrients</h5>
              <p className="text-sm text-emerald-700">{analysis.nutrientAdvice}</p>
            </div>
            <div className="p-4 bg-orange-50 rounded-2xl">
              <h5 className="font-bold text-orange-800 mb-2 uppercase text-xs tracking-widest">Pest Control</h5>
              <p className="text-sm text-orange-700">{analysis.pestPrevention}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResult;

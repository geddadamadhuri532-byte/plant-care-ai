
import React from 'react';
import { PlantAnalysis } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

interface MonitoringHistoryProps {
  history: PlantAnalysis[];
  onViewDetails: (analysis: PlantAnalysis) => void;
}

const MonitoringHistory: React.FC<MonitoringHistoryProps> = ({ history, onViewDetails }) => {
  if (history.length === 0) {
    return (
      <div className="text-center py-20 px-4">
        <div className="mb-6 inline-block p-6 bg-stone-100 rounded-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-stone-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-stone-800 mb-2">No History Found</h3>
        <p className="text-stone-500 max-w-sm mx-auto">Start scanning your plants to track their health progress over time.</p>
      </div>
    );
  }

  // Prepare chart data
  const chartData = [...history].reverse().map(h => ({
    date: new Date(h.timestamp).toLocaleDateString(),
    confidence: h.confidence * 100,
    healthy: h.isHealthy ? 100 : 0
  }));

  return (
    <div className="space-y-12 pb-12">
      <section>
        <h2 className="text-2xl font-bold text-stone-800 mb-6 px-4">Health Trends</h2>
        <div className="bg-white p-6 rounded-3xl shadow-sm border h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="date" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Line type="monotone" dataKey="confidence" stroke="#15803d" strokeWidth={3} dot={{ r: 6 }} activeDot={{ r: 8 }} name="Confidence Score" />
              <Line type="step" dataKey="healthy" stroke="#10b981" strokeWidth={2} name="Health Status" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold text-stone-800 mb-6 px-4">Recent Scans</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-4">
          {history.map((h) => (
            <div 
              key={h.id} 
              onClick={() => onViewDetails(h)}
              className="bg-white rounded-3xl border shadow-sm overflow-hidden cursor-pointer hover:shadow-xl hover:scale-[1.02] transition-all group"
            >
              <div className="aspect-square relative">
                <img src={h.image} alt={h.diseaseName} className="w-full h-full object-cover" />
                <div className="absolute top-4 left-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${h.isHealthy ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                    {h.isHealthy ? 'Healthy' : 'Diseased'}
                  </span>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-stone-800 truncate">{h.diseaseName}</h3>
                  <span className="text-xs text-stone-400">{new Date(h.timestamp).toLocaleDateString()}</span>
                </div>
                <p className="text-sm text-stone-500 line-clamp-2">{h.treatment}</p>
                <div className="mt-4 pt-4 border-t flex justify-between items-center text-xs font-bold text-green-700 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                  View Report
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default MonitoringHistory;

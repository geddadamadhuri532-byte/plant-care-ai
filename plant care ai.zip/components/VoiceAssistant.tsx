
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage, Type, FunctionDeclaration } from '@google/genai';
import { decode, decodeAudioData, encode } from '../services/audio';
import { AppView } from '../types';

interface VoiceAssistantProps {
  onNavigate?: (view: AppView) => void;
  onSearch?: (query: string) => void;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ onNavigate, onSearch }) => {
  const [isActive, setIsActive] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [transcription, setTranscription] = useState('');
  const [status, setStatus] = useState('Standby');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef(0);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Function Declarations for Gemini
  const navigateFunction: FunctionDeclaration = {
    name: 'navigateTo',
    parameters: {
      type: Type.OBJECT,
      description: 'Navigate to a specific section of the app.',
      properties: {
        view: {
          type: Type.STRING,
          description: 'The view to navigate to. Options: dashboard, scan, history, education, guide.',
        }
      },
      required: ['view'],
    },
  };

  const searchFunction: FunctionDeclaration = {
    name: 'searchPlantInfo',
    parameters: {
      type: Type.OBJECT,
      description: 'Search for plant care or disease information.',
      properties: {
        query: {
          type: Type.STRING,
          description: 'The plant or disease name to search for.',
        }
      },
      required: ['query'],
    },
  };

  const toggleAssistant = async () => {
    if (isActive) {
      stopSession();
      return;
    }

    try {
      setStatus('Connecting...');
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // Output Audio Context
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      if (audioContextRef.current.state === 'suspended') await audioContextRef.current.resume();

      // Input Audio Context
      if (!inputAudioCtxRef.current) {
        inputAudioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      }
      if (inputAudioCtxRef.current.state === 'suspended') await inputAudioCtxRef.current.resume();

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setStatus('Ready to help');
            setIsActive(true);
            
            if (inputAudioCtxRef.current && streamRef.current) {
              const source = inputAudioCtxRef.current.createMediaStreamSource(streamRef.current);
              const scriptProcessor = inputAudioCtxRef.current.createScriptProcessor(4096, 1, 1);
              scriptProcessorRef.current = scriptProcessor;
              
              scriptProcessor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                let sum = 0;
                for (let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
                setMicLevel(Math.sqrt(sum / inputData.length));

                const pcmBlob = {
                  data: encode(new Uint8Array(new Int16Array(inputData.map(v => v * 32768)).buffer)),
                  mimeType: 'audio/pcm;rate=16000'
                };
                sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
              };
              source.connect(scriptProcessor);
              scriptProcessor.connect(inputAudioCtxRef.current.destination);
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Transcriptions
            if (message.serverContent?.outputTranscription) {
              setTranscription(prev => prev + message.serverContent?.outputTranscription?.text);
            }

            // Handle Function Calls (App Control)
            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                let result = "Action performed";
                if (fc.name === 'navigateTo') {
                  const view = fc.args.view as AppView;
                  if (onNavigate) onNavigate(view);
                  result = `Navigated to ${view}`;
                } else if (fc.name === 'searchPlantInfo') {
                  if (onSearch) onSearch(fc.args.query as string);
                  result = `Searching for ${fc.args.query}`;
                }

                sessionPromise.then(s => s.sendToolResponse({
                  functionResponses: { id: fc.id, name: fc.name, response: { result } }
                }));
              }
            }

            // Handle Audio Output
            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && audioContextRef.current) {
              setIsSpeaking(true);
              setStatus('Assistant speaking...');
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
              const buffer = await decodeAudioData(decode(audioData), audioContextRef.current, 24000, 1);
              const source = audioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(audioContextRef.current.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) {
                  setIsSpeaking(false);
                  setStatus('Ready to help');
                }
              };
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsSpeaking(false);
            }

            if (message.serverContent?.turnComplete) setTranscription('');
          },
          onerror: (e) => {
            console.error("Live API Error:", e);
            setStatus('Connection error');
            stopSession();
          },
          onclose: () => {
            setIsActive(false);
            setIsSpeaking(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          tools: [{ functionDeclarations: [navigateFunction, searchFunction] }],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
          },
          systemInstruction: `You are Plant Care AI, a polite agricultural assistant. 
          CRITICAL: Detect the user's language automatically and respond fluently in the same language.
          
          Capabilities:
          1. Use 'navigateTo' to switch views: dashboard, scan, history, education, guide.
          2. Use 'searchPlantInfo' to look up care tips or diseases.
          
          Behavior:
          - Be concise but helpful.
          - If someone says "Scan a plant" or "Open the camera", call navigateTo('scan').
          - If someone says "How do I care for tomatoes?", call searchPlantInfo('tomato care') and explain what you are doing.`
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error("Failed to connect voice:", err);
      setStatus('Access denied');
      setIsActive(false);
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (scriptProcessorRef.current) scriptProcessorRef.current.disconnect();
    if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
    setIsActive(false);
    setIsSpeaking(false);
    setMicLevel(0);
    setStatus('Standby');
  };

  useEffect(() => { return () => stopSession(); }, []);

  return (
    <div className="fixed bottom-24 right-6 z-40">
      <div className={`absolute bottom-full right-0 mb-4 bg-white p-5 rounded-[2rem] shadow-2xl w-72 transition-all transform origin-bottom-right ${isActive ? 'scale-100 opacity-100 translate-y-0' : 'scale-90 opacity-0 translate-y-4 pointer-events-none'}`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${isSpeaking ? 'bg-blue-500 animate-ping' : 'bg-green-500 animate-pulse'}`}></div>
            <span className="text-xs font-bold uppercase tracking-widest text-stone-500">
              {isSpeaking ? 'Assistant speaking' : 'Listening...'}
            </span>
          </div>
          {!isSpeaking && isActive && (
            <div className="flex gap-0.5 items-end h-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="w-1 bg-green-500 rounded-full transition-all duration-100" style={{ height: `${Math.max(20, micLevel * (100 + i * 20))}%` }} />
              ))}
            </div>
          )}
        </div>
        <p className="text-sm text-stone-700 leading-relaxed italic min-h-[40px]">
          {transcription || (isSpeaking ? 'Thinking...' : status)}
        </p>
      </div>

      <button
        onClick={toggleAssistant}
        className={`p-6 rounded-full shadow-2xl transition-all active:scale-90 hover:scale-105 ${isActive ? 'bg-white text-red-500 border-2 border-red-500' : 'bg-green-700 text-white'}`}
      >
        {isActive ? (
          <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
        ) : (
          <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
        )}
      </button>
    </div>
  );
};

export default VoiceAssistant;

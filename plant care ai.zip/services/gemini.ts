
import { GoogleGenAI, Type } from "@google/genai";
import { PlantAnalysis, DiseaseInfo, CropDetail, AIAdvice } from "../types";

const API_KEY = process.env.API_KEY;

export const analyzePlantImage = async (base64Image: string): Promise<PlantAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const prompt = `Analyze this plant leaf image for diseases, nutritional deficiencies, or stress. 
  Be specific and return a detailed report. If the plant looks healthy, state so. 
  Include early risk factors if any subtle signs are visible.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { mimeType: 'image/jpeg', data: base64Image.split(',')[1] } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          diseaseName: { type: Type.STRING, description: "Common name of the disease or 'Healthy'" },
          confidence: { type: Type.NUMBER, description: "Confidence score 0.0 to 1.0" },
          symptoms: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Visible symptoms found in image"
          },
          severity: { 
            type: Type.STRING, 
            description: "Low, Moderate, High, or Critical" 
          },
          treatment: { type: Type.STRING, description: "Step-by-step treatment guide" },
          irrigationAdvice: { type: Type.STRING, description: "Watering recommendations" },
          nutrientAdvice: { type: Type.STRING, description: "Fertilizer or soil health recommendations" },
          pestPrevention: { type: Type.STRING, description: "Pest prevention strategies" },
          isHealthy: { type: Type.BOOLEAN, description: "Whether the plant is generally healthy" },
          earlyRiskFactors: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Subtle indicators of future problems"
          }
        },
        required: [
          "diseaseName", "confidence", "symptoms", "severity", 
          "treatment", "irrigationAdvice", "nutrientAdvice", 
          "pestPrevention", "isHealthy"
        ]
      }
    }
  });

  const analysis = JSON.parse(response.text || "{}");
  return {
    ...analysis,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    image: base64Image
  };
};

export const getDiseaseKnowledgeBase = async (): Promise<DiseaseInfo[]> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = "Provide a list of 6 common plant diseases for educational purposes. Include category, symptoms, and prevention.";
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING },
            description: { type: Type.STRING },
            symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
            prevention: { type: Type.STRING }
          },
          required: ["name", "category", "description", "symptoms", "prevention"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
};

export const getAIPlantAdvice = async (query: string): Promise<AIAdvice> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = `Act as an expert horticulturist. User question: "${query}". Provide a detailed response and 3-5 actionable tips.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          query: { type: Type.STRING },
          response: { type: Type.STRING },
          tips: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["query", "response", "tips"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};

export const getPlantEncyclopedia = async (): Promise<CropDetail[]> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = "Provide a comprehensive list of 8 common plants/crops (e.g., Tomato, Rose, Aloe Vera, etc.) with detailed care instructions including scientific name, light, water, soil, fertilizer, pruning, pests, and difficulty level.";

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            scientificName: { type: Type.STRING },
            sunlight: { type: Type.STRING },
            watering: { type: Type.STRING },
            soil: { type: Type.STRING },
            fertilizer: { type: Type.STRING },
            pruning: { type: Type.STRING },
            commonPests: { type: Type.ARRAY, items: { type: Type.STRING } },
            difficulty: { type: Type.STRING }
          },
          required: ["name", "scientificName", "sunlight", "watering", "soil", "difficulty"]
        }
      }
    }
  });

  return JSON.parse(response.text || "[]");
};
